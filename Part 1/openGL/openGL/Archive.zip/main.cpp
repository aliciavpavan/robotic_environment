/*******************************************|
 |											|
 |	Chinmay Desai							|
 |	301204565								|
 |	ENSC 488: Intro to Robotics				|
 |	Programming Assignment 2				|
 |	Prof. Shahram Payandeh					|
 |	Spring 2018
 
 glui
 opengl32
 glu32
 glut32|
 |											|
 |*******************************************/

//#ifdef _WIN32
//#include <GL/glut.h>
//#include "glui.h"
//#elif __APPLE__
//#include <GLUT/glut.h>
//#include <GLUI/glui.h>
//#elif __LINUX__
//#include <GL/glut.h>
//#endif

#include <GLFW/glfw3.h>

#include <algorithm>
#include <unistd.h>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <time.h>
#include <vector>
#include <iostream>
#include <cstdio>
#include <cstring>
#include <string.h>

#include <iostream>
#include <stdio.h> // Standard Input and Output Library

#include "objects.h"

using namespace std;

GLfloat cameraAngle = 12;
GLfloat cameraDistance = 0;
int arm_angles[5]={0, 0, 0, 0, 0};
int obs_check[14][14]={{0}};

// Variables for planar movement of the platform
int cz = -2;
int cx = -2;
int cy = 0;

int viax, viaz = 0;

void makeRobot(void)
{
	
	
	glScalef(0.5, 0.5, 0.5); // scale to make the base smaller
	
	//glClear(GL_COLOR_BUFFER_BIT);
	
	// Specify the vewing angles/distance
	glLoadIdentity();
	GLfloat x = cameraDistance * sin(cameraAngle);
	GLfloat y = cameraDistance;
	GLfloat z = cameraDistance * cos(cameraAngle);
	//	gluLookAt(x, y, z, 0, 0, 0, 1, 0, 0);
	gluLookAt(20, 10, 20, 0, 0, 0, 0, 1, 0);
	
	glTranslatef(cx, 0, cz);	// set the coordinated, intial are (5,0,5)
	glRotated(90, 0,0,1 );	// rotate so the arm is upright
	
	// Make Platform
	glPushMatrix();
	glColor3f(0, 1, 0);
	glTranslatef(-1.5, 0, 0);
	glScalef(0.25, 1, 1);
	glutSolidCube(1.5);
	glPopMatrix();
	
	// Make Wheel 1
	glPushMatrix();
	glColor3f(1, 0, 0);
	glTranslatef(-1.65, -0.75, -0.65);
	glScalef(0.1, 0.1, 0.1);
	glutSolidSphere(1.5, 20, 10);
	glPopMatrix();
	
	// Make Wheel 2
	glPushMatrix();
	glColor3f(1, 0, 0);
	glTranslatef(-1.65, 0.75, 0.65);
	glScalef(0.1, 0.1, 0.1);
	glutSolidSphere(1.5, 20, 10);
	glPopMatrix();
	
	// Make Wheel 3
	glPushMatrix();
	glColor3f(1, 0, 0);
	glTranslatef(-1.65, -0.75, 0.65);
	glScalef(0.1, 0.1, 0.1);
	glutSolidSphere(1.5, 20, 10);
	glPopMatrix();
	
	// Make Wheel 3
	glPushMatrix();
	glColor3f(1, 0, 0);
	glTranslatef(-1.65, 0.75, -0.65);
	glScalef(0.1, 0.1, 0.1);
	glutSolidSphere(1.5, 20, 10);
	glPopMatrix();
	
	glPushMatrix();
	// Roatate the sperhical base
	glRotatef((GLfloat)arm_angles[BASE_X], 1, 0, 0); // Rotation for  X
	glRotatef((GLfloat)arm_angles[BASE_Z], 0, 0, 1); // Rotation for Z
	
	// Make base
	glPushMatrix();
	glColor3f(0.5, 0.5, 0.5);		// Make it grey
	glutSolidSphere(1, 20, 10);	// Draw the base as a solid sphere
	glColor3f(1,0,0);				// Make it red
	glutWireSphere(1, 20, 10);	// Draw the base as a spherical wire frame
	glPopMatrix();
	
	glScalef(0.75, 0.75, 0.75); // scale to make arm smaller
	
	glTranslatef(1.0, 0, 0);	// Translate
	glRotatef((GLfloat)arm_angles[SHOULDER_Z], 0., 0., 1.); // Rotation for Z
	glTranslatef(1.5, 0, 0);		// Translate
	glPushMatrix();
	glScalef(3.0, 0.3, 0.3);
	glColor3f(0.25, 0.25, 0.25);	// Make it a dark shade grey
	glutSolidCube(1);				// Draw the shoulder link
	glPopMatrix();
	
	glTranslatef(1.5, 0, 0);	// Translate
	glRotatef((GLfloat)arm_angles[ELBOW_Z], 0., 0., 1.); //rotation on Z
	glTranslatef(1.0, 0, 0);	// Translate
	glPushMatrix();
	glScalef(2.0, 0.3, 0.3);
	glColor3f(0.5, 0.5, 0.5);	// Make it a normal shade of grey
	glutSolidCube(1);			// Draw the elbow link
								// glutWireCube(1);			// Wire Cube to make it more fancy
	glPopMatrix();
	
	glTranslatef(1.0, 0, 0);	// Translate
	glRotatef((GLfloat)arm_angles[WRIST_Z], 0, 0, 1); //rotation on Z
	glRotatef((GLfloat)arm_angles[WRIST_X], 1, 0, 0); //rotation on X
	
	glTranslatef(0.5, 0, 0); // Translate
	glPushMatrix();
	glScalef(1.0, 0.3, 0.3);
	glColor3f(0.75, 0.75, 0.75);	// Make it ligher shade of grey
	glutSolidCube(1);				// Draw the end effector (wrist)
									// glutWireCube(1);				// Wire Cube to make it more fancy
	
	//	glTranslatef(0.4, 0., 0.);
	//	glRotatef((GLfloat)arm_angles[PENCIL_Z], 0., 0., 1.); //bend on Z
	//	glRotatef((GLfloat)arm_angles[PENCIL_X], 1., 0., 0.); //rotation on X
	
	// Create the pencil tool of the robot
	glTranslatef(0.5, 0, 0);
	glPushMatrix();
	glScalef(1.2, 0.2, 0.1);
	glColor3f(1, 0, 0);
	glutSolidCube(1);
	glPopMatrix();
	
	glPopMatrix();
	glPopMatrix();
	
	glRotated(-90, 0,0,1 );
	glTranslatef(-cx, 0, -cz);
	
}

void change_angle(int angle, int delta, int minimum = 0, int maximum = 180)
{
	arm_angles[angle] = (arm_angles[angle] + delta) % 360;
	
	if (arm_angles[angle] > minimum)
	{	arm_angles[angle] = arm_angles[angle];	}
	else
	{	arm_angles[angle] = 0;	}
	
	
	if (arm_angles[angle] < maximum)
	{	arm_angles[angle] = arm_angles[angle];	}
	else
	{	arm_angles[angle] = 0;	}
	
}

// Now the fun part, putting everything together
void drawHouse(void)
{
	// Draw a 15 x 15 x 15 room
	
	drawWall(0, 0, 15, 15);
	//viaPoint(viax, viaz);
	
	//	 haptic();
	// Put the furniture in the room
	
	drawFloor();
	makeRug(); // Rug function needs to be called first so that the furniture can be places on top of it
	makeTable();
	makeShelf();
	makeChair();
	makeTV();
	makeRobot();
	
	return;
}

//void viaPoint(int viax, int viaz)
//{
//	glPushMatrix();
//	glColor3f(0, 0, 1);
//	glTranslatef(viax, 0, viaz);
//	glutSolidCube(2);
//	glPopMatrix();
//}

// Special keys to adjust the zoom and viewing
void specialKeys(int key, int x, int y)
{
	//	GLfloat distanceDelta = 1.0, angleDelta = 5 * 3.14159 / 180.0;
	
	// Up arrow key is pressed
	if (key == GLUT_KEY_UP)
	{
		//cameraDistance -= distanceDelta;
		// cameraDistance = ma(GLfloat)2.0, cameraDistance);
		
		//if( (GLfloat)2.0 > cameraDistance)
		//{ cameraDistance = (GLfloat)2.0; }
		//else
		//{cameraDistance = cameraDistance; }
		
		cout << "cz is " << cz << endl;
		
		
		if (cz > 14)
		{
			cz--;
		}
		if (cz < 14)
		{
			cz++;
		}
		else
		{
			cz = 14;
		}
	}
	
	// Down arrow key is pressed
	if (key == GLUT_KEY_DOWN)
	{
		// cameraDistance += distanceDelta;
		cout << cz << endl;
		if (cz > 0)
		{
			cz--;
		}
		if (cz < 0)
		{
			cz++;
		}
		
		
	}
	
	// Left arrow key is pressed
	if (key == GLUT_KEY_LEFT)
	{
		// cameraAngle -= angleDelta;
		
		if (cx > 0)
		{
			cx--;
		}
		if (cx < 0)
		{
			cx++;
		}
		
	}
	
	// Right arrow key is pressed
	if (key == GLUT_KEY_RIGHT)
	{
		// cameraAngle += angleDelta;
		
		cout << "cx is "<< cx << endl;
		
		if (cx > 14)
		{
			cx--;
		}
		if (cx < 14)
		{
			cx++;
		}
		else
		{
			cx = 14;
		}
	}
	
	glutPostRedisplay();
}


// Function for keyboard entry to manipulate the haptic device
void keyboard(unsigned char key, int x, int y)
{
	// This determines the number of steps/interval it takes for each press of the letter
	// Ex: if delta is 5, each time a letter is pressed the device will move by 5 degrees
	// Set delta to 1 so that each time a letter is pressed, the device will move by 1 degree only
	int delta = 5;
	
	
	switch (key)
	{
			// Exit case by hitting 'ESC' key
		case 27: //ESC in ASCII
			exit(0);
			
			// The Base is rotated using ASWD
			// Move the BASE_X joint in + & - diections
		case 'a':
			change_angle(BASE_X, delta, -180, 0);
			break;
		case 'd':
			change_angle(BASE_X, -delta, -180, 0);
			break;
			
			// Move the BASE_Z joint in + & - diections
		case 'w':
			change_angle(BASE_Z, delta, -90, 90);
			break;
		case 's':
			change_angle(BASE_Z, -delta, -90, 90);
			break;
			
			// Move the SHOULDER_Z joint in + & - diections
		case 'n':
			change_angle(SHOULDER_Z, delta, 0, 135);
			break;
		case 'm':
			change_angle(SHOULDER_Z, -delta, 0, 135);
			break;
			
			// Move the ELBOW_Z joint in + & - diections
		case 'j':
			change_angle(ELBOW_Z, delta, 0, 135);
			break;
		case 'k':
			change_angle(ELBOW_Z, -delta, 0, 135);
			break;
			
			// Move the WRIST_X joint in + & - diections
		case 'p':
			change_angle(WRIST_X, delta, -45, 45);
			break;
		case 'l':
			change_angle(WRIST_X, -delta, -45, 45);
			break;
			
			// Move the WRIST_Z joint in + & - diections
		case 'i':
			change_angle(WRIST_Z, delta, -15, 90);
			break;
		case 'o':
			change_angle(WRIST_Z, -delta, -15, 90);
			break;
	}
	glutPostRedisplay();
}


// Function Prototypes
void display(void);
void init(void);

// Main Display Function
void display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	// Display the masterpiece on the screen
	drawHouse();
	
	
	drawHumanoid(0, 0, 14); //Standing left of Char1
	drawHumanoid(0, 0, 10); // Standing between the chairs
	drawHumanoid(9, 0, 1); // Standing between TV and bookshelf
	
	// Two people standing having a conversation
	// drawHumanoid(10, 9, 10);
	// drawHumanoid(9, 5, 12);
	
	// Uncomment below to have a humanoid party of nine
	/*
	 drawHumanoid(0, 0, 0);
	 drawHumanoid(10, 8, 8);
	 drawHumanoid(13, 14, 6);
	 drawHumanoid(8, 0, 14);
	 */
	
	glFlush();
	return;
}


void init()
{
	
	// Set the current clear color to black and the current drawing color to white.
	glClearColor(0.7, 0.7, 0.7, 1.0);
	glColor3f(1.0, 1.0, 1.0);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity(); // Reset View
	gluPerspective(90.0, 16 / 9, 1, 100);
	
	// Position camera at (x,y,z) looking at (0, 0, 0) with the vector
	// <0, 1, 0> pointing upward.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	// <eye point> <reference point> <up vector>
	// (eye X, eye Y, eye Z, center X, center Y, center, Z, up X, up Y, up Z)
	gluLookAt(20, 10, 20, 0, 0, 0, 0, 1, 0);
	
	return;
	
}


int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(80, 80);
	glutInitWindowSize(800, 600);	// Size the window
	glutCreateWindow("488 ROBOTICS PROJECT"); // give the window an awesome name
	glutDisplayFunc(display);
	glutSpecialFunc(specialKeys);
	glutKeyboardFunc(keyboard);
	
	
	// Enter the postion of through the command window
	//cout << "Please Enter the desired X postion of the robot: ";
	//cin >> cx;
	
	//cout << "Please Enter the desired Z postion of the robot: " ;
	//cin >> cz;
	
	int goalx, goalz = 0;
	
	cout << "Please enter Goal point X: ";
	cin >> goalx;
	
	cout << "Please enter Goal point Z: ";
	cin >> goalz;
	
	cout << "Please enter Via point X: ";
	cin >> viax;
	
	cout << "Please enter Via point Z: ";
	cin >> viaz;
	
	
	
	if (obs_check[viaz][viax] != 0)
	{
		cout << "There is an obstacle. Goodbye." << endl;
	}
	else
	{
		for (int i = 0; i < viax; i++)
		{
			cx++;
			init();
			display();
			//		makeRobot();
			sleep(1000);
			glutPostRedisplay();
			
		}
		
		for (int j = 0; j < viaz; j++)
		{
			cz++;
			init();
			display();
			//	makeRobot();
			sleep(1000);
			glutPostRedisplay();
			
		}
		
	}
	
	cout << "Via point reached" << endl;
	sleep(2000);
	
	
	int greaterx = 0;
	
	if (viax > goalx)
	{
		greaterx = 1;
	}
	else
	{
		greaterx = 0;
	}
	
	
	for (int i = 0; i < abs(goalx-viax); i++)
	{
		if (greaterx > 0)
		{
			cx--;
		}
		else
		{
			cx++;
		}
		init();
		display();
		//		makeRobot();
		sleep(1000);
		glutPostRedisplay();
		
	}
	
	int greaterz = 0;
	
	if (viaz > goalz)
	{
		greaterz = 1;
	}
	else
	{
		greaterz = 0;
	}
	
	for (int j = 0; j < abs(goalz - viaz); j++)
	{
		if (greaterz > 0)
		{
			cz--;
			if (obs_check[cz + 1][cx + 1] != 0)
			{
				cout << "There is an obstacle" << endl;
			}
		}
		else
		{
			cz++;
		}
		init();
		display();
			makeRobot();
		sleep(1000);
		glutPostRedisplay();
		
	}
	cout << "You have arrived at your destination!" << endl;
	init();
	glutMainLoop();
	
	
	return 0;
}
