//
//  objects.h
//  openGL
//
//  Created by Alicia Pavan on 2018-04-01.
//  Copyright © 2018 alicia. All rights reserved.
//
#ifdef _WIN32
#include <GL/glut.h>
#include "glui.h"
#elif __APPLE__
#include <GLUT/glut.h>
#include <GLUI/glui.h>
#elif __LINUX__
#include <GL/glut.h>
#endif

#ifndef objects_h
#define objects_h

extern int arm_angles[5];
enum { BASE_X, BASE_Z, SHOULDER_Z, ELBOW_Z, WRIST_X, WRIST_Z };
extern GLfloat cameraDistance;
extern GLfloat cameraAngle;
extern int obs_check[14][14];

void drawSquarePrism(float, float, float, float);
void drawRectPrism(float, float, float, float, float, float);
void drawWall(float, float, float, float);
void drawFloor(void);
void makeTable(void);
void makeRug(void);
void makeShelf(void);
void makeChair(void);
void makeTV(void);
void drawHumanoid(float, float, float);

#endif /* objects_h */
